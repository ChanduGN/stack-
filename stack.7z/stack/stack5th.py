class Stack:
    def __init__(self):
        self.items = []
    def is_empty(self):
        return self.items == []
    def size(self):
        return len(self.items)
    def push(self, item):
        self.items.append(item)
    def pop(self):
        return self.items.pop()
    def peek(self):
        return self.items[-1]

    #Returns string representation of contents of stack
    def __str__(self):
        return

from Stack import Stack

#Processes HTML file and returns list of HTML tag objects
def process_html_file(sample_html):
    tag_list = []
    s =Stack()
    with open(sample.html, 'r') as f:
        all_lines = []
        # loop through all lines using f.readlines() method
        for line in f.readlines():
            new_line = []
            # this is how you would loop through each alphabet
            for chars in line:
                new_line.append(chars)
            all_lines.append(new_line)
