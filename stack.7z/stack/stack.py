class myStack:
    def __init__(self):
        self.data=[]
        self.count=0
    def isEmpty(self):
        return self.count==0
    def getcount(self):
        return self.count
    def stackPush(self,x):
        self.data.append(x)
        self.count+=1
    def stackPop(self):
        if not self.isEmpty():
            self.count-=1
            return self.pop()
        else:
            return None
    def stackPeek(self):
        if not self.isEmpty():
            return self.data[-1]
        else:
            return None
    def displayInfo(self):
        print(self.data,self.count)


def testEmpty():
    s1=myStack()
    assert(s1.getcount()==0)
def testPush():
    s1=myStack()
    assert(s1.getcount()==0)
    s1.stackPush(10)
    s1.stackPush(20)
    s1.stackPush(30)
    s1.displayInfo()
    a=s1.stackPeek()
    print(a)
    assert(s1.isEmpty()==0)
    
testEmpty()
testPush()
